#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '=== Contrôle de présence des livrables ==='
for file in README.md PROCEDURE.md ARCHITECTURE.md SECURITY-REPORT.md CADRAGE.md RUNBOOKS.md TESTS.md COUTS-AWS.md SECURITE-CIBLE.md DEMO.md LICENSE; do
  [[ -s "$file" ]] && echo "OK $file" || echo "MANQUANT $file"
done
for dir in infra/organizations infra/iam-dev infra/log-archive infra/cloudtrail infra/network; do
  [[ -d "$dir" ]] && echo "OK $dir" || echo "A FUSIONNER $dir (code local non inclus dans ce pack)"
done
[[ -f scripts/detect_cloudtrail.py ]] && echo 'OK detect_cloudtrail.py' || echo 'A FUSIONNER detect_cloudtrail.py du dépôt local'

echo '=== Contrôle des fichiers sensibles suivis par Git ==='
if command -v git >/dev/null && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git ls-files | grep -E '(^|/)(terraform\.tfstate(\.backup)?|\.env|ministack-data/)' && {
    echo 'ALERTE : fichiers sensibles suivis par Git. Corriger avant publication.' >&2; exit 1;
  } || true
fi

echo '=== Tests de syntaxe du module de compte (si OpenTofu présent) ==='
if command -v tofu >/dev/null; then
  tofu fmt -check -recursive infra/account-factory || true
fi

echo '=== Note ==='
echo 'Un contrôle documentaire ne remplace pas un déploiement et des tests fonctionnels.'
